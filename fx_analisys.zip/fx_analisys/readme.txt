# 起動方法
1.node 8以上をインストールする。10.3が望ましい
2.package.jsonがある階層で下記を実行
npm install
3.実行コマンドを入力
cd src
node main.js

差分があるデータがresult/result.csvに出力されます